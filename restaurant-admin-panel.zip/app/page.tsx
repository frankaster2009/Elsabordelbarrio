import { DashboardProvider } from "@/components/dashboard-provider"
import { DashboardShell } from "@/components/dashboard-shell"

export default function Page() {
  return (
    <DashboardProvider>
      <DashboardShell />
    </DashboardProvider>
  )
}
