"use client"

import { useState } from "react"
import { Menu, ShieldCheck, User } from "lucide-react"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button, buttonVariants } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { AdminSidebar } from "./admin-sidebar"
import { useDashboard } from "./dashboard-provider"
import { MenuView } from "./views/menu-view"
import { OrdersView } from "./views/orders-view"
import { ReportsView } from "./views/reports-view"
import { ReviewsView } from "./views/reviews-view"
import { SettingsView } from "./views/settings-view"

export type ViewKey = "pedidos" | "menu" | "reportes" | "resenas" | "configuracion"

const titles: Record<ViewKey, { title: string; subtitle: string }> = {
  pedidos: { title: "Pedidos en Curso", subtitle: "Control de pedidos recibidos en tiempo real" },
  menu: { title: "Gestión de Menú", subtitle: "Edita productos, precios y disponibilidad" },
  reportes: { title: "Reportes", subtitle: "Productos más y menos vendidos del mes" },
  resenas: { title: "Reseñas de Clientes", subtitle: "Modera, oculta o elimina comentarios" },
  configuracion: { title: "Configuración", subtitle: "Datos del local y permisos de acceso" },
}

export function DashboardShell() {
  const [view, setView] = useState<ViewKey>("pedidos")
  const [mobileOpen, setMobileOpen] = useState(false)
  const { role, setRole } = useDashboard()
  const header = titles[view]

  return (
    <div className="flex min-h-screen bg-background">
      <AdminSidebar
        active={view}
        onNavigate={setView}
        mobileOpen={mobileOpen}
        onClose={() => setMobileOpen(false)}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center gap-4 border-b border-border bg-card/95 px-4 py-3 backdrop-blur sm:px-6">
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => setMobileOpen(true)}
            aria-label="Abrir menú"
          >
            <Menu className="size-5" />
          </Button>

          <div className="min-w-0 flex-1">
            <h1 className="truncate text-lg font-bold text-foreground sm:text-xl">{header.title}</h1>
            <p className="hidden truncate text-sm text-muted-foreground sm:block">{header.subtitle}</p>
          </div>

          <DropdownMenu>
            <DropdownMenuTrigger className={cn(buttonVariants({ variant: "outline" }), "h-11 gap-2")}>
              <Avatar className="size-7">
                <AvatarFallback className="bg-primary text-xs text-primary-foreground">
                  {role === "encargado" ? "EN" : "EM"}
                </AvatarFallback>
              </Avatar>
              <span className="hidden text-left leading-tight sm:block">
                <span className="block text-sm font-semibold capitalize">{role}</span>
                <span className="block text-xs text-muted-foreground">
                  {role === "encargado" ? "Acceso total" : "Acceso limitado"}
                </span>
              </span>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel>Cambiar rol (demo)</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={() => setRole("encargado")} className="gap-2">
                <ShieldCheck className="size-4" />
                Encargado
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setRole("empleado")} className="gap-2">
                <User className="size-4" />
                Empleado
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        <main className="flex-1 p-4 sm:p-6">
          {view === "pedidos" && <OrdersView />}
          {view === "menu" && <MenuView />}
          {view === "reportes" && <ReportsView />}
          {view === "resenas" && <ReviewsView />}
          {view === "configuracion" && <SettingsView />}
        </main>
      </div>
    </div>
  )
}
