"use client"

import { ShieldCheck, User } from "lucide-react"
import { toast } from "sonner"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { useDashboard } from "@/components/dashboard-provider"

export function SettingsView() {
  const { role, setRole } = useDashboard()

  return (
    <div className="grid max-w-3xl gap-4">
      <Card>
        <CardHeader>
          <CardTitle>Datos del local</CardTitle>
          <CardDescription>Información visible para clientes y personal.</CardDescription>
        </CardHeader>
        <CardContent>
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              toast.success("Configuración guardada")
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="local">Nombre del restaurante</Label>
              <Input id="local" defaultValue="El Sabor del Barrio" />
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="phone">Teléfono</Label>
                <Input id="phone" defaultValue="+57 320 123 4567" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="hours">Horario</Label>
                <Input id="hours" defaultValue="Lun–Dom · 11:00 a 22:00" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Dirección</Label>
              <Input id="address" defaultValue="Calle 45 #12-30, Barrio Centro" />
            </div>
            <Button type="submit" className="h-11 font-semibold">
              Guardar cambios
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Permisos de acceso</CardTitle>
          <CardDescription>
            Controla quién puede administrar el menú. Solo los encargados pueden editar productos y
            precios.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <button
            onClick={() => setRole("encargado")}
            className={`flex w-full items-center gap-3 rounded-md border p-4 text-left transition-colors ${
              role === "encargado" ? "border-primary bg-accent/40" : "border-border hover:bg-muted/60"
            }`}
          >
            <ShieldCheck className="size-6 text-primary" />
            <div className="flex-1">
              <p className="font-semibold text-foreground">Encargado</p>
              <p className="text-sm text-muted-foreground">Acceso total: menú, reportes y reseñas.</p>
            </div>
            {role === "encargado" && <span className="text-xs font-bold text-primary">ACTIVO</span>}
          </button>
          <button
            onClick={() => setRole("empleado")}
            className={`flex w-full items-center gap-3 rounded-md border p-4 text-left transition-colors ${
              role === "empleado" ? "border-primary bg-accent/40" : "border-border hover:bg-muted/60"
            }`}
          >
            <User className="size-6 text-muted-foreground" />
            <div className="flex-1">
              <p className="font-semibold text-foreground">Empleado</p>
              <p className="text-sm text-muted-foreground">
                Solo pedidos y consulta. No puede editar el menú.
              </p>
            </div>
            {role === "empleado" && <span className="text-xs font-bold text-primary">ACTIVO</span>}
          </button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Notificaciones</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {[
            { label: "Sonido al recibir un pedido nuevo", def: true },
            { label: "Alerta de plato agotado", def: true },
            { label: "Resumen diario de ventas por correo", def: false },
          ].map((n, i) => (
            <div key={n.label}>
              {i > 0 && <Separator />}
              <div className="flex items-center justify-between py-3">
                <span className="text-sm text-foreground">{n.label}</span>
                <Switch defaultChecked={n.def} />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
