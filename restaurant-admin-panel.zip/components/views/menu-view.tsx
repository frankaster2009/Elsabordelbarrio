"use client"

import { useState } from "react"
import { Lock, Pencil, Plus } from "lucide-react"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { useDashboard } from "@/components/dashboard-provider"
import { formatCurrency } from "@/lib/format"
import type { MenuCategory, MenuItem } from "@/lib/types"

const categories: MenuCategory[] = ["Entradas", "Platos fuertes", "Bebidas", "Postres"]

const emptyItem: MenuItem = {
  id: "",
  name: "",
  description: "",
  category: "Platos fuertes",
  price: 0,
  available: true,
  soldThisMonth: 0,
}

export function MenuView() {
  const { menu, toggleAvailability, saveMenuItem, role } = useDashboard()
  const [editing, setEditing] = useState<MenuItem | null>(null)
  const canEdit = role === "encargado"

  return (
    <div className="space-y-4">
      {!canEdit && (
        <Card className="flex flex-row items-center gap-3 border-accent bg-accent/40 p-4">
          <Lock className="size-5 shrink-0 text-accent-foreground" />
          <p className="text-sm text-accent-foreground">
            Estás en modo <strong>empleado</strong>. La edición del menú está reservada para encargados.
            Cambia de rol arriba a la derecha para administrar productos.
          </p>
        </Card>
      )}

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          {menu.length} productos · {menu.filter((m) => m.available).length} disponibles
        </p>
        <Button
          className="h-11 gap-2 font-semibold"
          disabled={!canEdit}
          onClick={() => setEditing({ ...emptyItem, id: `m${Date.now()}` })}
        >
          <Plus className="size-4" />
          Nuevo producto
        </Button>
      </div>

      <Card className="overflow-hidden p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/60">
                <TableHead className="min-w-[220px]">Producto</TableHead>
                <TableHead>Categoría</TableHead>
                <TableHead className="text-right">Precio</TableHead>
                <TableHead className="text-center">Disponible</TableHead>
                <TableHead className="text-right">Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {menu.map((item) => (
                <TableRow key={item.id} className={item.available ? "" : "opacity-60"}>
                  <TableCell>
                    <p className="font-semibold text-foreground">{item.name}</p>
                    <p className="max-w-sm truncate text-xs text-muted-foreground">{item.description}</p>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{item.category}</Badge>
                  </TableCell>
                  <TableCell className="text-right font-semibold tabular-nums text-foreground">
                    {formatCurrency(item.price)}
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center justify-center gap-2">
                      <Switch
                        checked={item.available}
                        disabled={!canEdit}
                        onCheckedChange={() => {
                          toggleAvailability(item.id)
                          toast.success(
                            `${item.name} ${item.available ? "deshabilitado" : "habilitado"}`,
                          )
                        }}
                        aria-label={`Disponibilidad de ${item.name}`}
                      />
                      <span className="hidden text-xs text-muted-foreground sm:inline">
                        {item.available ? "Sí" : "No"}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-9 gap-1"
                      disabled={!canEdit}
                      onClick={() => setEditing(item)}
                    >
                      <Pencil className="size-3.5" />
                      Editar
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>

      <MenuItemDialog
        item={editing}
        onClose={() => setEditing(null)}
        onSave={(item) => {
          saveMenuItem(item)
          toast.success("Producto guardado")
          setEditing(null)
        }}
      />
    </div>
  )
}

function MenuItemDialog({
  item,
  onClose,
  onSave,
}: {
  item: MenuItem | null
  onClose: () => void
  onSave: (item: MenuItem) => void
}) {
  const [draft, setDraft] = useState<MenuItem | null>(item)

  // sync when a new item is opened
  if (item && (!draft || draft.id !== item.id)) setDraft(item)
  if (item && !draft) setDraft(item)

  const current = item ? draft ?? item : null

  return (
    <Dialog open={!!item} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Editar producto</DialogTitle>
          <DialogDescription>
            Los cambios se reflejan de inmediato en la carta del restaurante.
          </DialogDescription>
        </DialogHeader>

        {current && (
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault()
              onSave(current)
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="name">Nombre del plato</Label>
              <Input
                id="name"
                value={current.name}
                required
                onChange={(e) => setDraft({ ...current, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                rows={3}
                value={current.description}
                onChange={(e) => setDraft({ ...current, description: e.target.value })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="price">Precio (COP)</Label>
                <Input
                  id="price"
                  type="number"
                  min={0}
                  step={500}
                  value={current.price}
                  onChange={(e) => setDraft({ ...current, price: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-2">
                <Label>Categoría</Label>
                <Select
                  value={current.category}
                  onValueChange={(v) => setDraft({ ...current, category: v as MenuCategory })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="flex items-center justify-between rounded-md border border-border p-3">
              <div>
                <p className="text-sm font-semibold text-foreground">Disponible en carta</p>
                <p className="text-xs text-muted-foreground">Desactiva para agotar el plato</p>
              </div>
              <Switch
                checked={current.available}
                onCheckedChange={(v) => setDraft({ ...current, available: v })}
              />
            </div>

            <DialogFooter>
              <Button type="button" variant="outline" className="h-11" onClick={onClose}>
                Cancelar
              </Button>
              <Button type="submit" className="h-11 font-semibold">
                Guardar cambios
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  )
}
