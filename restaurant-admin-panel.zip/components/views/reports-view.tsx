"use client"

import { useMemo } from "react"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis } from "recharts"
import { ArrowDownRight, ArrowUpRight, DollarSign, TrendingUp } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart"
import { useDashboard } from "@/components/dashboard-provider"
import { formatCurrency } from "@/lib/format"

const chartConfig: ChartConfig = {
  soldThisMonth: { label: "Unidades vendidas", color: "var(--chart-1)" },
}

function StatCard({
  label,
  value,
  hint,
  icon: Icon,
}: {
  label: string
  value: string
  hint: string
  icon: React.ElementType
}) {
  return (
    <Card>
      <CardContent className="flex items-center gap-4 p-5">
        <div className="flex size-11 items-center justify-center rounded-md bg-accent text-accent-foreground">
          <Icon className="size-5" />
        </div>
        <div>
          <p className="text-sm text-muted-foreground">{label}</p>
          <p className="text-2xl font-bold text-foreground">{value}</p>
          <p className="text-xs text-muted-foreground">{hint}</p>
        </div>
      </CardContent>
    </Card>
  )
}

export function ReportsView() {
  const { menu } = useDashboard()

  const sorted = useMemo(() => [...menu].sort((a, b) => b.soldThisMonth - a.soldThisMonth), [menu])
  const top = sorted.slice(0, 5)
  const bottom = [...sorted].slice(-5).reverse()

  const totalUnits = menu.reduce((s, m) => s + m.soldThisMonth, 0)
  const estRevenue = menu.reduce((s, m) => s + m.soldThisMonth * m.price, 0)

  const topData = top.map((m) => ({ name: m.name, soldThisMonth: m.soldThisMonth }))

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <StatCard
          label="Unidades vendidas"
          value={totalUnits.toLocaleString("es-CO")}
          hint="Este mes"
          icon={TrendingUp}
        />
        <StatCard
          label="Ingresos estimados"
          value={formatCurrency(estRevenue)}
          hint="Este mes"
          icon={DollarSign}
        />
        <StatCard
          label="Producto estrella"
          value={top[0]?.name ?? "—"}
          hint={`${top[0]?.soldThisMonth ?? 0} unidades`}
          icon={ArrowUpRight}
        />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Productos más vendidos</CardTitle>
          <CardDescription>Top 5 del mes por unidades vendidas</CardDescription>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <BarChart accessibilityLayer data={topData} margin={{ left: 4, right: 12 }}>
              <CartesianGrid vertical={false} strokeDasharray="3 3" />
              <XAxis
                dataKey="name"
                tickLine={false}
                axisLine={false}
                tickMargin={8}
                interval={0}
                tick={{ fontSize: 11 }}
              />
              <YAxis tickLine={false} axisLine={false} width={32} tick={{ fontSize: 11 }} />
              <ChartTooltip cursor={false} content={<ChartTooltipContent />} />
              <Bar dataKey="soldThisMonth" fill="var(--color-soldThisMonth)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <RankList
          title="Más vendidos"
          icon={ArrowUpRight}
          tone="text-chart-3"
          items={top}
        />
        <RankList
          title="Menos vendidos"
          icon={ArrowDownRight}
          tone="text-destructive"
          items={bottom}
        />
      </div>
    </div>
  )
}

function RankList({
  title,
  icon: Icon,
  tone,
  items,
}: {
  title: string
  icon: React.ElementType
  tone: string
  items: { id: string; name: string; soldThisMonth: number; category: string }[]
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <Icon className={`size-5 ${tone}`} />
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-1">
        {items.map((m, i) => (
          <div
            key={m.id}
            className="flex items-center justify-between rounded-md px-2 py-2.5 hover:bg-muted/60"
          >
            <div className="flex items-center gap-3">
              <span className="flex size-7 items-center justify-center rounded-full bg-muted text-xs font-bold text-muted-foreground">
                {i + 1}
              </span>
              <div>
                <p className="text-sm font-semibold text-foreground">{m.name}</p>
                <p className="text-xs text-muted-foreground">{m.category}</p>
              </div>
            </div>
            <span className="text-sm font-bold tabular-nums text-foreground">{m.soldThisMonth}</span>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
