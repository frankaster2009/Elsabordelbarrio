"use client"

import { useMemo, useState } from "react"
import { Eye, EyeOff, Star, Trash2 } from "lucide-react"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useDashboard } from "@/components/dashboard-provider"
import type { Review } from "@/lib/types"
import { cn } from "@/lib/utils"

type Filter = "todas" | "positivas" | "negativas" | "ocultas"

function Stars({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5" aria-label={`${rating} de 5 estrellas`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star
          key={i}
          className={cn(
            "size-4",
            i < rating ? "fill-chart-2 text-chart-2" : "fill-muted text-muted",
          )}
        />
      ))}
    </div>
  )
}

export function ReviewsView() {
  const { reviews, toggleReviewHidden, deleteReview } = useDashboard()
  const [filter, setFilter] = useState<Filter>("todas")
  const [toDelete, setToDelete] = useState<Review | null>(null)

  const filtered = useMemo(() => {
    switch (filter) {
      case "positivas":
        return reviews.filter((r) => r.rating >= 4)
      case "negativas":
        return reviews.filter((r) => r.rating <= 2)
      case "ocultas":
        return reviews.filter((r) => r.hidden)
      default:
        return reviews
    }
  }, [reviews, filter])

  const avg =
    reviews.length > 0
      ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
      : "0.0"

  return (
    <div className="space-y-4">
      <Card className="flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <Star className="size-6 fill-chart-2 text-chart-2" />
            <span className="text-2xl font-bold text-foreground">{avg}</span>
          </div>
          <div className="text-sm text-muted-foreground">
            <p className="font-medium text-foreground">Calificación promedio</p>
            <p>{reviews.length} reseñas · {reviews.filter((r) => r.hidden).length} ocultas</p>
          </div>
        </div>
        <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)}>
          <TabsList>
            <TabsTrigger value="todas">Todas</TabsTrigger>
            <TabsTrigger value="positivas">Positivas</TabsTrigger>
            <TabsTrigger value="negativas">Negativas</TabsTrigger>
            <TabsTrigger value="ocultas">Ocultas</TabsTrigger>
          </TabsList>
        </Tabs>
      </Card>

      <div className="space-y-3">
        {filtered.length === 0 ? (
          <Card className="p-10 text-center text-sm text-muted-foreground">
            No hay reseñas en este filtro.
          </Card>
        ) : (
          filtered.map((review) => (
            <Card
              key={review.id}
              className={cn("gap-0 p-4", review.hidden && "border-dashed bg-muted/40")}
            >
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <p className="font-semibold text-foreground">{review.customer}</p>
                    {review.hidden && (
                      <Badge variant="secondary" className="gap-1 text-xs">
                        <EyeOff className="size-3" />
                        Oculta
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-3">
                    <Stars rating={review.rating} />
                    <span className="text-xs text-muted-foreground">{review.date}</span>
                    <Badge variant="outline" className="text-xs">
                      {review.dish}
                    </Badge>
                  </div>
                </div>
              </div>

              <p
                className={cn(
                  "my-3 text-sm leading-relaxed text-foreground",
                  review.hidden && "text-muted-foreground line-through decoration-muted-foreground/40",
                )}
              >
                {review.comment}
              </p>

              <div className="flex flex-wrap gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="h-9 gap-1.5"
                  onClick={() => {
                    toggleReviewHidden(review.id)
                    toast.success(review.hidden ? "Reseña visible" : "Reseña oculta")
                  }}
                >
                  {review.hidden ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
                  {review.hidden ? "Mostrar" : "Ocultar"}
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-9 gap-1.5 text-destructive hover:bg-destructive/10 hover:text-destructive"
                  onClick={() => setToDelete(review)}
                >
                  <Trash2 className="size-4" />
                  Eliminar
                </Button>
              </div>
            </Card>
          ))
        )}
      </div>

      <Dialog open={!!toDelete} onOpenChange={(open) => !open && setToDelete(null)}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Eliminar reseña</DialogTitle>
            <DialogDescription>
              Esta acción no se puede deshacer. El comentario de {toDelete?.customer} se eliminará
              permanentemente.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" className="h-11" onClick={() => setToDelete(null)}>
              Cancelar
            </Button>
            <Button
              variant="destructive"
              className="h-11 gap-1.5"
              onClick={() => {
                if (toDelete) {
                  deleteReview(toDelete.id)
                  toast.success("Reseña eliminada")
                }
                setToDelete(null)
              }}
            >
              <Trash2 className="size-4" />
              Sí, eliminar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
