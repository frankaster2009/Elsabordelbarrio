"use client"

import { useEffect, useState } from "react"
import { Bike, Check, ChevronRight, Clock, ShoppingBag, Utensils } from "lucide-react"
import { toast } from "sonner"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { useDashboard } from "@/components/dashboard-provider"
import { formatCurrency, timeAgo } from "@/lib/format"
import type { Order, OrderStatus } from "@/lib/types"
import { cn } from "@/lib/utils"

const columns: { status: OrderStatus; label: string; accent: string }[] = [
  { status: "nuevo", label: "Nuevos", accent: "border-t-primary" },
  { status: "preparando", label: "En preparación", accent: "border-t-chart-2" },
  { status: "listo", label: "Listos para entregar", accent: "border-t-chart-3" },
]

const channelIcon = {
  mesa: Utensils,
  "para llevar": ShoppingBag,
  delivery: Bike,
}

const nextLabel: Record<OrderStatus, string> = {
  nuevo: "Empezar a preparar",
  preparando: "Marcar como listo",
  listo: "Marcar entregado",
  entregado: "Entregado",
}

function OrderCard({ order }: { order: Order }) {
  const { advanceOrder, cancelOrder } = useDashboard()
  const Channel = channelIcon[order.channel]
  const [mounted, setMounted] = useState(false)

  useEffect(() => setMounted(true), [])

  return (
    <Card className="gap-0 border-border p-4 shadow-sm">
      <div className="flex items-start justify-between gap-2">
        <div>
          <p className="text-base font-bold text-foreground">{order.code}</p>
          <p className="text-sm text-muted-foreground">{order.customer}</p>
        </div>
        <Badge variant="secondary" className="gap-1 capitalize">
          <Channel className="size-3.5" />
          {order.channel}
        </Badge>
      </div>

      <ul className="my-3 space-y-1 border-y border-dashed border-border py-3 text-sm">
        {order.items.map((item, i) => (
          <li key={i} className="flex justify-between text-foreground">
            <span>
              <span className="font-semibold">{item.quantity}×</span> {item.name}
            </span>
          </li>
        ))}
      </ul>

      <div className="mb-3 flex items-center justify-between">
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="size-3.5" />
          <span suppressHydrationWarning>{mounted ? timeAgo(order.createdAt) : ""}</span>
        </span>
        <span className="text-base font-bold text-foreground">{formatCurrency(order.total)}</span>
      </div>

      <div className="flex flex-col gap-2">
        <Button
          className="h-11 w-full justify-center gap-2 text-sm font-semibold"
          onClick={() => {
            advanceOrder(order.id)
            toast.success(`Pedido ${order.code} actualizado`)
          }}
        >
          {order.status === "listo" ? <Check className="size-4" /> : <ChevronRight className="size-4" />}
          {nextLabel[order.status]}
        </Button>
        <Button
          variant="ghost"
          className="h-9 w-full text-xs text-muted-foreground hover:text-destructive"
          onClick={() => {
            cancelOrder(order.id)
            toast(`Pedido ${order.code} cancelado`)
          }}
        >
          Cancelar pedido
        </Button>
      </div>
    </Card>
  )
}

export function OrdersView() {
  const { orders } = useDashboard()

  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
      {columns.map((col) => {
        const colOrders = orders.filter((o) => o.status === col.status)
        return (
          <section
            key={col.status}
            className={cn("rounded-lg border border-t-4 border-border bg-card/50 p-3", col.accent)}
          >
            <div className="mb-3 flex items-center justify-between px-1">
              <h2 className="text-sm font-bold uppercase tracking-wide text-foreground">{col.label}</h2>
              <span className="flex size-6 items-center justify-center rounded-full bg-muted text-xs font-bold text-muted-foreground">
                {colOrders.length}
              </span>
            </div>
            <div className="space-y-3">
              {colOrders.length === 0 ? (
                <p className="rounded-md border border-dashed border-border py-8 text-center text-sm text-muted-foreground">
                  Sin pedidos
                </p>
              ) : (
                colOrders.map((order) => <OrderCard key={order.id} order={order} />)
              )}
            </div>
          </section>
        )
      })}
    </div>
  )
}
