"use client"

import { createContext, useCallback, useContext, useMemo, useState } from "react"
import { initialMenu, initialOrders, initialReviews } from "@/lib/mock-data"
import type { MenuItem, Order, OrderStatus, Review } from "@/lib/types"

export type Role = "encargado" | "empleado"

interface DashboardContextValue {
  role: Role
  setRole: (role: Role) => void
  orders: Order[]
  advanceOrder: (id: string) => void
  cancelOrder: (id: string) => void
  menu: MenuItem[]
  toggleAvailability: (id: string) => void
  saveMenuItem: (item: MenuItem) => void
  reviews: Review[]
  toggleReviewHidden: (id: string) => void
  deleteReview: (id: string) => void
}

const DashboardContext = createContext<DashboardContextValue | null>(null)

const statusOrder: OrderStatus[] = ["nuevo", "preparando", "listo", "entregado"]

export function DashboardProvider({ children }: { children: React.ReactNode }) {
  const [role, setRole] = useState<Role>("encargado")
  const [orders, setOrders] = useState<Order[]>(initialOrders)
  const [menu, setMenu] = useState<MenuItem[]>(initialMenu)
  const [reviews, setReviews] = useState<Review[]>(initialReviews)

  const advanceOrder = useCallback((id: string) => {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o
        const next = statusOrder[Math.min(statusOrder.indexOf(o.status) + 1, statusOrder.length - 1)]
        return { ...o, status: next }
      }),
    )
  }, [])

  const cancelOrder = useCallback((id: string) => {
    setOrders((prev) => prev.filter((o) => o.id !== id))
  }, [])

  const toggleAvailability = useCallback((id: string) => {
    setMenu((prev) => prev.map((m) => (m.id === id ? { ...m, available: !m.available } : m)))
  }, [])

  const saveMenuItem = useCallback((item: MenuItem) => {
    setMenu((prev) => {
      const exists = prev.some((m) => m.id === item.id)
      if (exists) return prev.map((m) => (m.id === item.id ? item : m))
      return [...prev, item]
    })
  }, [])

  const toggleReviewHidden = useCallback((id: string) => {
    setReviews((prev) => prev.map((r) => (r.id === id ? { ...r, hidden: !r.hidden } : r)))
  }, [])

  const deleteReview = useCallback((id: string) => {
    setReviews((prev) => prev.filter((r) => r.id !== id))
  }, [])

  const value = useMemo<DashboardContextValue>(
    () => ({
      role,
      setRole,
      orders,
      advanceOrder,
      cancelOrder,
      menu,
      toggleAvailability,
      saveMenuItem,
      reviews,
      toggleReviewHidden,
      deleteReview,
    }),
    [
      role,
      orders,
      advanceOrder,
      cancelOrder,
      menu,
      toggleAvailability,
      saveMenuItem,
      reviews,
      toggleReviewHidden,
      deleteReview,
    ],
  )

  return <DashboardContext.Provider value={value}>{children}</DashboardContext.Provider>
}

export function useDashboard() {
  const ctx = useContext(DashboardContext)
  if (!ctx) throw new Error("useDashboard must be used within DashboardProvider")
  return ctx
}
