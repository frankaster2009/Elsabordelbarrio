"use client"

import { BarChart3, ClipboardList, MessageSquare, Settings, UtensilsCrossed, X } from "lucide-react"
import { cn } from "@/lib/utils"
import { useDashboard } from "./dashboard-provider"
import type { ViewKey } from "./dashboard-shell"

const navItems: { key: ViewKey; label: string; icon: React.ElementType; hint: string }[] = [
  { key: "pedidos", label: "Pedidos en Curso", icon: ClipboardList, hint: "Control en tiempo real" },
  { key: "menu", label: "Gestión de Menú", icon: UtensilsCrossed, hint: "Editar platos y precios" },
  { key: "reportes", label: "Reportes", icon: BarChart3, hint: "Ventas del mes" },
  { key: "resenas", label: "Reseñas", icon: MessageSquare, hint: "Moderar comentarios" },
  { key: "configuracion", label: "Configuración", icon: Settings, hint: "Local y permisos" },
]

interface Props {
  active: ViewKey
  onNavigate: (view: ViewKey) => void
  mobileOpen: boolean
  onClose: () => void
}

export function AdminSidebar({ active, onNavigate, mobileOpen, onClose }: Props) {
  const { orders } = useDashboard()
  const activeOrders = orders.filter((o) => o.status !== "entregado").length

  return (
    <>
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 bg-foreground/40 lg:hidden"
          onClick={onClose}
          aria-hidden="true"
        />
      )}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-sidebar-border bg-sidebar transition-transform lg:static lg:z-auto lg:translate-x-0",
          mobileOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="flex items-center justify-between gap-3 border-b border-sidebar-border px-5 py-5">
          <div className="flex items-center gap-3">
            <div className="flex size-11 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <UtensilsCrossed className="size-6" aria-hidden="true" />
            </div>
            <div className="leading-tight">
              <p className="text-base font-bold text-sidebar-foreground">El Sabor del Barrio</p>
              <p className="text-xs text-muted-foreground">Panel de administración</p>
            </div>
          </div>
          <button
            className="rounded-md p-1 text-muted-foreground hover:bg-sidebar-accent lg:hidden"
            onClick={onClose}
            aria-label="Cerrar menú"
          >
            <X className="size-5" />
          </button>
        </div>

        <nav className="flex-1 space-y-1.5 overflow-y-auto p-3" aria-label="Navegación principal">
          {navItems.map((item) => {
            const isActive = active === item.key
            const Icon = item.icon
            return (
              <button
                key={item.key}
                onClick={() => {
                  onNavigate(item.key)
                  onClose()
                }}
                aria-current={isActive ? "page" : undefined}
                className={cn(
                  "flex w-full items-center gap-3 rounded-md px-3 py-3 text-left transition-colors",
                  isActive
                    ? "bg-primary text-primary-foreground shadow-sm"
                    : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                )}
              >
                <Icon className="size-5 shrink-0" aria-hidden="true" />
                <span className="flex-1">
                  <span className="block text-sm font-semibold">{item.label}</span>
                  <span
                    className={cn(
                      "block text-xs",
                      isActive ? "text-primary-foreground/80" : "text-muted-foreground",
                    )}
                  >
                    {item.hint}
                  </span>
                </span>
                {item.key === "pedidos" && activeOrders > 0 && (
                  <span
                    className={cn(
                      "flex size-6 items-center justify-center rounded-full text-xs font-bold",
                      isActive ? "bg-primary-foreground text-primary" : "bg-primary text-primary-foreground",
                    )}
                  >
                    {activeOrders}
                  </span>
                )}
              </button>
            )
          })}
        </nav>

        <div className="border-t border-sidebar-border p-4 text-xs text-muted-foreground">
          <p className="font-medium text-sidebar-foreground">Turno activo</p>
          <p>Lun–Dom · 11:00 a 22:00</p>
        </div>
      </aside>
    </>
  )
}
