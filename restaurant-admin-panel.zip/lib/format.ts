export function formatCurrency(value: number): string {
  return new Intl.NumberFormat("es-CO", {
    style: "currency",
    currency: "COP",
    maximumFractionDigits: 0,
  }).format(value)
}

export function timeAgo(timestamp: number): string {
  const diff = Math.floor((Date.now() - timestamp) / 60000)
  if (diff < 1) return "hace instantes"
  if (diff === 1) return "hace 1 min"
  if (diff < 60) return `hace ${diff} min`
  const hours = Math.floor(diff / 60)
  return hours === 1 ? "hace 1 h" : `hace ${hours} h`
}
