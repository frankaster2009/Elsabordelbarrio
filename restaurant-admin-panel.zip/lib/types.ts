export type OrderStatus = "nuevo" | "preparando" | "listo" | "entregado"

export type OrderChannel = "mesa" | "para llevar" | "delivery"

export interface OrderItem {
  name: string
  quantity: number
}

export interface Order {
  id: string
  code: string
  customer: string
  channel: OrderChannel
  table?: string
  items: OrderItem[]
  total: number
  status: OrderStatus
  createdAt: number
}

export type MenuCategory = "Entradas" | "Platos fuertes" | "Bebidas" | "Postres"

export interface MenuItem {
  id: string
  name: string
  description: string
  category: MenuCategory
  price: number
  available: boolean
  soldThisMonth: number
}

export interface Review {
  id: string
  customer: string
  rating: number
  comment: string
  date: string
  dish: string
  hidden: boolean
}
